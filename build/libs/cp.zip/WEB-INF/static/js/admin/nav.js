var navs = [{
	"title" : "后台首页",
	"icon" : "icon-computer",
	"href" : "/success",
	"spread" : false
},{
	"title" : "科目列表",
	"icon" : "icon-text",
	"href" : "/admin/subjects",
	"spread" : false
}]
